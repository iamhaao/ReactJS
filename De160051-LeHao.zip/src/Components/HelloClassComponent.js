import { Component } from 'react'

class HelloClass extends Component {
    render() {
        return <h1>Hello REACT Class Component </h1>
    }

}
export default HelloClass

