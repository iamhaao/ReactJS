import { Component } from "react";


function HelloFunction() {
    return <h1>HELLO REACT FUNCTION Component</h1>
}
export default HelloFunction;